// Import the express module
const express = require('express');
// Initialize an express application
const app = express();
// Define the port number for the server
const port = 3000;
// Import JSON data from a file
const data = require('./data/data.json');

// Define a route to display JSON data
app.get('/data', (req, res) => {
  // Send the JSON data as the response
  res.json(data);
});

// Start the server and listen on the specified port
app.listen(port, () => {
  // Log a message to the console once the server is running
  console.log(`Server running at http://localhost:${port}`);
});
