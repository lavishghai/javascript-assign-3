const express = require('express');
const app = express();
const port = 3000;

app.use(express.json());

// Simulated data
let items = [
  { id: 1, name: 'Item1' },
  { id: 2, name: 'Item2' }
];

// Create
app.post('/items', (req, res) => {
  const newItem = { id: items.length + 1, ...req.body };
  items.push(newItem);
  res.status(201).json(newItem);
});

// Read
app.get('/items', (req, res) => {
  res.json(items);
});

// Update
app.put('/items/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const itemIndex = items.findIndex(item => item.id === id);
  if (itemIndex !== -1) {
    items[itemIndex] = { id, ...req.body };
    res.json(items[itemIndex]);
  } else {
    res.status(404).send('Item not found');
  }
});

// Delete
app.delete('/items/:id', (req, res) => {
  const id = parseInt(req.params.id);
  items = items.filter(item => item.id !== id);
  res.status(204).send();
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
