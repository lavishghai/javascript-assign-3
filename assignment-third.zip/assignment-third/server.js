const express = require('express');
const app = express();
const port = 3000;

// Home route displaying group names
app.get('/', (req, res) => {
  res.send('<h1>Group Names</h1><p>LAVISH GHAI, [Partner\'s Name: GURPREET KAUR]</p>');
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
